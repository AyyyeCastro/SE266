<?php
//$root is my way of copying the intentions of __DIR__. Due to these PHP files being stored in finalProject/backend, and not in the root folder. 
// Rather than declaring the root path everytime, I stored it's path into the $root variable, and concactinated it's value when needed. 
$root ="C:/xampp/htdocs/SE266/REPO-Folder/SE266/finalProject"
?>